::::::::::::::::::::::::::::::::Info::::::::::::::::::::::::::::::::

Adobe Photoshop Custom Shapes: Maritime
Copyright (C) Luke Roberts 2006 
Web: lukeroberts.deviantart.com
Email: lukeroberts@gmail.com


::::::::::::::::::::::::::::Installation::::::::::::::::::::::::::::

Just put them in the Photoshop Presets > Custom Shapes folder. It 
will most likely be something like:

C:\Program Files\Adobe\Photoshop Folder\Presets\Custom Shapes

Then, in Photoshop, open the Custom Shape Tool (Press U on the 
keyboard and choose the rounded star shape), and in the Custom 
Shapes box just load the shapes like you would load a normal brush.

For a more detailed explaination of how to load them, go here:
http://www.deviantart.com/deviation/21727644/

Made with Photoshop CS2 so they should work with CS and 7 etc.


:::::::::::::::::::::::::::::::Usage::::::::::::::::::::::::::::::::


This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 2.5 License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/2.5/ or send a letter to Creative Commons, 543 Howard Street, 5th Floor, San Francisco, California, 94105, USA.


:::::::::::::::::::::::::::::Disclaimer:::::::::::::::::::::::::::::

By installing these Custom Shapes you agree that I (Luke Roberts) 
cannot be held liable for any damages to your computer whatsoever 
from them.

(It's unlikely that it would but I had to say the legal stuff 
somewhere)